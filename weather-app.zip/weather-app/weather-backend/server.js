const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
app.use(cors());

console.log("Server file loaded...");

app.get("/weather", async (req, res) => {
    const city = req.query.city;
    const apiKey = process.env.API_KEY;

    if (!city) {
        return res.status(400).json({ error: "City is required" });
    }

    if (!apiKey) {
        return res.status(500).json({ error: "API_KEY missing in .env" });
    }

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    try {
        const response = await fetch(url); // Node v24 built-in fetch
        const data = await response.json();
        res.json(data);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to fetch weather" });
    }
});

app.listen(3000, () => {
    console.log("✅ Backend running on http://localhost:3000");
});
